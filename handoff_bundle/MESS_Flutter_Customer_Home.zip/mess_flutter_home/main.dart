import 'package:flutter/material.dart';

void main() => runApp(const MessApp());

const Color ink = Color(0xFF17212B);
const Color orange = Color(0xFFFF9F1C);
const Color cream = Color(0xFFFFF9F0);
const Color muted = Color(0xFF7A828A);
const Color green = Color(0xFF2F8F5B);

class MessApp extends StatelessWidget {
  const MessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MESS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: orange, primary: ink, surface: Colors.white),
        fontFamily: 'Roboto',
      ),
      home: const CustomerHomePage(),
    );
  }
}

class CustomerHomePage extends StatefulWidget {
  const CustomerHomePage({super.key});

  @override
  State<CustomerHomePage> createState() => _CustomerHomePageState();
}

class _CustomerHomePageState extends State<CustomerHomePage> {
  int _tab = 0;
  int _mealTab = 0;
  bool _delivery = false;
  String _location = 'Knowledge Park, Greater Noida';
  String _search = '';

  final List<MessPlace> _places = const [
    MessPlace('Ghar Jaisa Khana', 'North Indian • Veg', '4.7', '₹2,199', '1.2 km', '🍲', 'Lunch & Dinner'),
    MessPlace('Campus Tiffin Co.', 'Homestyle • Veg/Non-veg', '4.5', '₹1,899', '850 m', '🍱', 'Lunch & Dinner'),
    MessPlace('Daily Dabba Kitchen', 'Thali • Fresh meals', '4.6', '₹2,399', '1.8 km', '🥗', 'Lunch only'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _tab,
          children: [
            _buildHome(),
            _SimpleTab(icon: Icons.receipt_long_rounded, title: 'Your orders', subtitle: 'Your meal bookings and delivery updates will appear here.'),
            _SimpleTab(icon: Icons.card_membership_rounded, title: 'My subscriptions', subtitle: 'Manage your active plans, meal balance and renewals here.'),
            _SimpleTab(icon: Icons.person_rounded, title: 'Your profile', subtitle: 'Manage your details, saved addresses and preferences.'),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        backgroundColor: Colors.white,
        indicatorColor: orange.withOpacity(.20),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long_rounded), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.card_membership_outlined), selectedIcon: Icon(Icons.card_membership_rounded), label: 'Plans'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildHome() {
    final visiblePlaces = _places.where((p) => '${p.name} ${p.cuisine}'.toLowerCase().contains(_search.toLowerCase())).toList();
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.soup_kitchen_rounded, color: orange, size: 25)),
              const SizedBox(width: 10),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('MESS', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.4, color: ink)),
                Text('Your Meals. Your Choice.', style: TextStyle(fontSize: 10, color: muted, letterSpacing: .2)),
              ]),
              const Spacer(),
              IconButton.filledTonal(onPressed: () => _showMessage('Notifications will appear here.'), icon: const Icon(Icons.notifications_none_rounded), style: IconButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ink)),
            ]),
            const SizedBox(height: 22),
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _chooseLocation,
              child: Row(children: [
                const Icon(Icons.location_on_rounded, color: orange, size: 22),
                const SizedBox(width: 8),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('DELIVERING / EATING NEAR', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: .8, color: muted)),
                  const SizedBox(height: 3),
                  Text(_location, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, color: ink, fontSize: 14)),
                ])),
                const Icon(Icons.keyboard_arrow_down_rounded, color: ink),
              ]),
            ),
            const SizedBox(height: 18),
            TextField(
              onChanged: (value) => setState(() => _search = value),
              decoration: InputDecoration(
                hintText: 'Search mess, tiffin or favourite food',
                hintStyle: const TextStyle(color: muted, fontSize: 13),
                prefixIcon: const Icon(Icons.search_rounded, color: ink),
                suffixIcon: IconButton(onPressed: () => _showMessage('Filters: distance, price, rating and food preference.'), icon: const Icon(Icons.tune_rounded, color: ink)),
                filled: true, fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 22),
            _buildHero(),
            const SizedBox(height: 24),
            _sectionHeader('Your meal, your way', 'Choose how you eat'),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _modeCard(icon: Icons.storefront_rounded, title: 'Eat offline', subtitle: 'Visit the mess', selected: !_delivery, onTap: () => setState(() => _delivery = false)),),
              const SizedBox(width: 12),
              Expanded(child: _modeCard(icon: Icons.delivery_dining_rounded, title: 'Get delivery', subtitle: 'Extra delivery fee', selected: _delivery, onTap: () => setState(() => _delivery = true)),),
            ]),
            const SizedBox(height: 24),
            _sectionHeader('Pick your plan', 'Flexible subscriptions'),
            const SizedBox(height: 12),
            _buildPlanStrip(),
            const SizedBox(height: 24),
            _sectionHeader('What are you craving?', 'Choose a meal'),
            const SizedBox(height: 12),
            Row(children: [
              _mealChoice('Lunch', Icons.wb_sunny_rounded, 0),
              const SizedBox(width: 10),
              _mealChoice('Dinner', Icons.nightlight_round, 1),
            ]),
            const SizedBox(height: 24),
            _sectionHeader('Near you', '${visiblePlaces.length} places to explore'),
            const SizedBox(height: 12),
          ]),
        )),
        if (visiblePlaces.isEmpty)
          const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No providers match your search. Try another name.', style: TextStyle(color: muted)))))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            sliver: SliverList.separated(
              itemCount: visiblePlaces.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) => _providerCard(visiblePlaces[index]),
            ),
          ),
      ],
    );
  }

  Widget _buildHero() => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [ink, Color(0xFF263746)]),
      boxShadow: [BoxShadow(color: ink.withOpacity(.12), blurRadius: 18, offset: const Offset(0, 8))],
    ),
    child: Stack(children: [
      Positioned(right: -10, top: 8, child: Icon(Icons.ramen_dining_rounded, size: 110, color: Colors.white.withOpacity(.07))),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: orange.withOpacity(.18), borderRadius: BorderRadius.circular(20)), child: const Text('GOOD FOOD. SMART PLANS.', style: TextStyle(color: orange, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1))),
        const SizedBox(height: 13),
        const Text('Your daily meals,\nsorted.', style: TextStyle(color: Colors.white, fontSize: 27, height: 1.12, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text('Find trusted local messes and save with meal plans.', style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12, height: 1.4)),
        const SizedBox(height: 16),
        FilledButton(onPressed: () => _showMessage('Explore nearby providers below.'), style: FilledButton.styleFrom(backgroundColor: orange, foregroundColor: ink, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Text('Explore messes', style: TextStyle(fontWeight: FontWeight.w800)), SizedBox(width: 8), Icon(Icons.arrow_forward_rounded, size: 17)])),
      ]),
    ]),
  );

  Widget _modeCard({required IconData icon, required String title, required String subtitle, required bool selected, required VoidCallback onTap}) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180), padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: selected ? const Color(0xFFFFE9C8) : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: selected ? orange : const Color(0xFFF0E9DF), width: selected ? 1.5 : 1)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: selected ? orange : cream, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: ink)), const Spacer(), if (selected) const Icon(Icons.check_circle_rounded, color: green, size: 19)]),
        const SizedBox(height: 12), Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 14)),
        const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
      ]),
    ),
  );

  Widget _buildPlanStrip() => SizedBox(height: 126, child: ListView(scrollDirection: Axis.horizontal, children: [
    _planCard('1 MONTH', 'Flexible start', 'Popular'),
    const SizedBox(width: 10), _planCard('3 MONTHS', 'Save more', 'Best value'),
    const SizedBox(width: 10), _planCard('6 / 12 MONTHS', 'Long-term plans', 'More savings'),
  ]));

  Widget _planCard(String title, String subtitle, String badge) => Container(
    width: 178, padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFF0E9DF))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: const Color(0xFFFFE9C8), borderRadius: BorderRadius.circular(8)), child: Text(badge.toUpperCase(), style: const TextStyle(color: Color(0xFF995600), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .5))),
      const Spacer(), Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 14)),
      const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
    ]),
  );

  Widget _mealChoice(String label, IconData icon, int value) {
    final selected = _mealTab == value;
    return Expanded(child: InkWell(onTap: () => setState(() => _mealTab = value), borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14), decoration: BoxDecoration(color: selected ? ink : Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: selected ? ink : const Color(0xFFF0E9DF))), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: selected ? orange : muted, size: 19), const SizedBox(width: 8), Text(label, style: TextStyle(color: selected ? Colors.white : ink, fontWeight: FontWeight.w800, fontSize: 13))]))));
  }

  Widget _providerCard(MessPlace place) => InkWell(
    onTap: () => _showMessage('${place.name}\n${place.cuisine}\nPlans from ${place.price} per month. Connect provider details to open the full profile.'),
    borderRadius: BorderRadius.circular(20),
    child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFF0E9DF))), child: Row(children: [
      Container(width: 82, height: 88, decoration: BoxDecoration(color: const Color(0xFFFFE9C8), borderRadius: BorderRadius.circular(15)), child: Center(child: Text(place.emoji, style: const TextStyle(fontSize: 38)))),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(place.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 14))), const Icon(Icons.star_rounded, color: orange, size: 17), Text(place.rating, style: const TextStyle(color: ink, fontSize: 11, fontWeight: FontWeight.w800))]),
        const SizedBox(height: 5), Text(place.cuisine, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 11)),
        const SizedBox(height: 7), Row(children: [const Icon(Icons.location_on_outlined, size: 13, color: muted), Text(place.distance, style: const TextStyle(color: muted, fontSize: 10)), const SizedBox(width: 8), const Icon(Icons.restaurant_menu_rounded, size: 13, color: muted), Expanded(child: Text(place.slots, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 10)))]),
        const SizedBox(height: 9), Row(children: [Text('${place.price}', style: const TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 15)), const Text(' / month', style: TextStyle(color: muted, fontSize: 10)), const Spacer(), Icon(_delivery ? Icons.delivery_dining_rounded : Icons.storefront_rounded, size: 16, color: orange), const SizedBox(width: 3), Text(_delivery ? 'Delivery' : 'Pickup', style: const TextStyle(color: muted, fontSize: 10, fontWeight: FontWeight.w700))]),
      ])),
      const SizedBox(width: 4), const Icon(Icons.chevron_right_rounded, color: muted),
    ])),
  );

  Widget _sectionHeader(String title, String subtitle) => Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: muted, fontSize: 11))])), TextButton(onPressed: () => _showMessage('Showing all available options.'), child: const Text('See all', style: TextStyle(color: Color(0xFF995600), fontWeight: FontWeight.w800, fontSize: 12)))]);

  Future<void> _chooseLocation() async {
    final controller = TextEditingController(text: _location);
    final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      backgroundColor: cream, title: const Text('Choose your location', style: TextStyle(color: ink, fontWeight: FontWeight.w900)),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'Enter area, hostel or PIN code')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save'))],
    ));
    if (result != null && result.isNotEmpty) setState(() => _location = result);
  }

  void _showMessage(String message) => showDialog<void>(context: context, builder: (context) => AlertDialog(
    backgroundColor: cream, content: Text(message, style: const TextStyle(color: ink, height: 1.4)),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Got it'))],
  ));
}

class MessPlace {
  final String name, cuisine, rating, price, distance, emoji, slots;
  const MessPlace(this.name, this.cuisine, this.rating, this.price, this.distance, this.emoji, this.slots);
}

class _SimpleTab extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const _SimpleTab({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Container(width: 76, height: 76, decoration: BoxDecoration(color: orange.withOpacity(.18), borderRadius: BorderRadius.circular(24)), child: Icon(icon, color: ink, size: 36)),
    const SizedBox(height: 18), Text(title, style: const TextStyle(fontSize: 22, color: ink, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.5)),
  ])));
}

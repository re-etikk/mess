# MESS Flutter Customer Home Screen

This is a self-contained Flutter `main.dart` demo for the MESS customer/student home screen.

## Run
1. Create a Flutter project: `flutter create mess_customer_app`
2. Replace `mess_customer_app/lib/main.dart` with this `main.dart`.
3. Run `flutter run`.

No third-party packages are required. The screen includes interactive location editing, search filtering, pickup/delivery selection, lunch/dinner selection, plan cards, provider cards, and bottom navigation. Provider data is demo-only; connect it to the MESS backend before production.
